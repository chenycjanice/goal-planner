# 目標理財規劃器

用 PV、FV、PMT 設定理財目標，分析達成度並提供補足缺口的建議。純靜態網站（HTML / CSS / JavaScript），沒有建置步驟。

## 功能
- 四個預設目標：退休金、購屋頭期款、子女教育金、緊急預備金
- 計算 FV（期末資產）、PMT（達標每月投入）、PV（缺口一次投入）、通膨調整後目標
- 預期 / 保守 / 樂觀三種情境的資產成長圖
- 依缺口自動產生建議，並提供不同報酬率下的對照表

## 檔案結構
```
index.html   頁面結構
style.css    樣式（支援淺色 / 深色模式）
app.js       計算與畫面邏輯
_headers     Cloudflare Pages 的標頭設定
```

## 本機預覽
直接用瀏覽器開啟 `index.html`，或執行 `python3 -m http.server 8000` 後開啟 http://localhost:8000

## 上傳到 GitHub
```
cd finance-planner
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<你的帳號>/finance-planner.git
git push -u origin main
```
（先在 GitHub 建立同名的空 repository，不要勾選建立 README。）

## 部署到 Cloudflare Pages
1. Cloudflare 控制台 → Workers & Pages → Create application → Pages → Connect to Git
2. 授權並選擇 `finance-planner` repository
3. Build settings：Framework preset 選 None，Build command 留空，Build output directory 填 `/`（或留空）
4. Save and Deploy，完成後會得到 `*.pages.dev` 網址

之後每次 push 到 `main`，Cloudflare 會自動重新部署。

## 注意
本工具為試算，假設報酬率固定、每月月底投入，未計稅費與市場波動，不構成投資建議。
