var G=[
{n:"退休金",target:15000000,years:25,pv:500000,pmt:15000,rate:6,inf:2,inc:70000},
{n:"購屋頭期款",target:3000000,years:7,pv:300000,pmt:20000,rate:4,inf:2,inc:80000},
{n:"子女教育金",target:2000000,years:15,pv:100000,pmt:6000,rate:5,inf:2,inc:70000},
{n:"緊急預備金",target:300000,years:2,pv:20000,pmt:8000,rate:1.5,inf:2,inc:50000}];
var F=["target","years","pv","pmt","rate","inf","inc"],cur=0,$=function(i){return document.getElementById(i)};
function fm(v){var a=Math.abs(v),s=v<0?"-":"";if(a>=1e8)return s+"NT$ "+(a/1e8).toFixed(2)+" 億";if(a>=1e4)return s+"NT$ "+(Math.round(a/100)/100).toLocaleString("zh-TW")+" 萬";return s+"NT$ "+Math.round(a).toLocaleString("zh-TW")}
function mr(y){return Math.pow(1+y/100,1/12)-1}
function fv(pv,pmt,y,yrs){var r=mr(y),N=Math.round(yrs*12),g=Math.pow(1+r,N);return pv*g+(r===0?pmt*N:pmt*(g-1)/r)}
function reqPmt(T,pv,y,yrs){var r=mr(y),N=Math.round(yrs*12),g=Math.pow(1+r,N),need=T-pv*g;return need<=0?0:(r===0?need/N:need*r/(g-1))}
function reqRate(T,pv,pmt,yrs){var lo=-5,hi=50;if(fv(pv,pmt,hi,yrs)<T)return null;for(var i=0;i<60;i++){var m=(lo+hi)/2;fv(pv,pmt,m,yrs)<T?lo=m:hi=m}return hi}
function reqYears(T,pv,pmt,y){for(var m=1;m<=960;m++){if(fv(pv,pmt,y,m/12)>=T)return m/12}return null}
function read(){var o={};F.forEach(function(f){o[f]=parseFloat($(f).value)||0});return o}
function load(){F.forEach(function(f){$(f).value=G[cur][f]})}
function save(){var o=read();F.forEach(function(f){G[cur][f]=o[f]})}
function tabs(){var h="";G.forEach(function(g,i){h+='<button aria-pressed="'+(i==cur)+'" data-i="'+i+'">'+g.n+'</button>'});$("tabs").innerHTML=h;
[].forEach.call($("tabs").children,function(b){b.onclick=function(){save();cur=+b.dataset.i;tabs();load();calc()}})}
function chart(o,T){var W=640,H=280,L=58,R=12,Tp=14,B=28,n=Math.max(1,Math.round(o.years)),S=[["#8aa4ab",o.rate-2,1.5],["var(--bl)",o.rate+2,1.5],["var(--ac)",o.rate,3]],
D=S.map(function(s){var a=[];for(var k=0;k<=n;k++)a.push(fv(o.pv,o.pmt,s[1],k));return a}),mx=Math.max(T,Math.max.apply(null,D[1]))*1.05;
var X=function(k){return L+(W-L-R)*k/n},Y=function(v){return Tp+(H-Tp-B)*(1-v/mx)},s="";
for(var i=0;i<=4;i++){var v=mx*i/4,y=Y(v);s+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'" stroke="var(--ln)"/><text x="'+(L-6)+'" y="'+(y+4)+'" text-anchor="end" font-size="11" fill="var(--mu)">'+fm(v).replace("NT$ ","")+'</text>'}
var st=Math.max(1,Math.ceil(n/6));for(var k=0;k<=n;k+=st)s+='<text x="'+X(k)+'" y="'+(H-8)+'" text-anchor="middle" font-size="11" fill="var(--mu)">第'+k+'年</text>';
s+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+Y(T)+'" y2="'+Y(T)+'" stroke="var(--wa)" stroke-width="2" stroke-dasharray="6 4"/>';
S.forEach(function(c,j){var p=D[j].map(function(v,k){return(k?"L":"M")+X(k).toFixed(1)+" "+Y(v).toFixed(1)}).join("");s+='<path d="'+p+'" fill="none" stroke="'+c[0]+'" stroke-width="'+c[2]+'" stroke-linejoin="round"/>'});
var e=D[2][n];s+='<circle cx="'+X(n)+'" cy="'+Y(e)+'" r="5" fill="var(--ac)"/>';
$("chart").innerHTML='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="資產成長預測圖">'+s+'</svg>'}
function calc(){var o=read(),yrs=Math.max(1,o.years),T=o.target*Math.pow(1+o.inf/100,yrs),E=fv(o.pv,o.pmt,o.rate,yrs),gap=T-E,ok=gap<=0,pct=Math.min(100,E/T*100);
var fvPV=o.pv*Math.pow(1+mr(o.rate),Math.round(yrs*12)),fvP=E-fvPV,paid=o.pv+o.pmt*yrs*12;
$("hero").className="hero "+(ok?"ok":"no");
$("hero").innerHTML='<p class="t">'+(ok?"照目前計畫，可以達成目標":"照目前計畫，還差 "+fm(gap))+'</p><div>'+yrs+' 年後預估資產 <b>'+fm(E)+'</b>，通膨調整後的目標是 <b>'+fm(T)+'</b></div><div class="bar"><i style="width:'+pct+'%"></i></div><small>目標達成度 '+pct.toFixed(1)+'%</small>';
$("kpi").innerHTML='<div><small>FV：期末預估資產</small><strong>'+fm(E)+'</strong><em>本金投入 '+fm(paid)+'，投資收益 '+fm(E-paid)+'</em></div>'+
'<div><small>PMT：達標每月需投入</small><strong>'+fm(reqPmt(T,o.pv,o.rate,yrs))+'</strong><em>目前每月投入 '+fm(o.pmt)+'</em></div>'+
'<div><small>PV：缺口一次投入需要</small><strong>'+fm(ok?0:gap/Math.pow(1+o.rate/100,yrs))+'</strong><em>今天就一次補足缺口所需金額</em></div>';
chart(o,T);
var h="",rp=reqPmt(T,o.pv,o.rate,yrs),ry=reqYears(T,o.pv,o.pmt,o.rate),rr=reqRate(T,o.pv,o.pmt,yrs);
if(ok){h+='<div><b>目前的計畫足夠，還有 '+fm(-gap)+' 的緩衝</b><span>可以保留緩衝應對報酬不如預期；若保守情境（報酬 '+(o.rate-2)+'%）下仍達標，代表計畫相當穩健。'+(fv(o.pv,o.pmt,o.rate-2,yrs)>=T?'你的計畫在保守情境下也能達標。':'但在保守情境下會差 '+fm(T-fv(o.pv,o.pmt,o.rate-2,yrs))+'，建議保留彈性。')+'</span></div>';
 var lp=reqPmt(T,o.pv,o.rate,yrs);h+='<div><b>每月投入可以降到 '+fm(lp)+'</b><span>若想提早讓出現金流，這是在預期報酬下的最低每月投入。</span></div>'}
else{
 h+='<div><b>方案一：每月多存 '+fm(rp-o.pmt)+'（共 '+fm(rp)+'）</b><span>維持年限與報酬率，最直接可控的方式。'+(o.inc>0?'約占月收入 '+(rp/o.inc*100).toFixed(0)+'%'+(rp/o.inc>0.3?'，負擔偏重，建議搭配其他方案。':'，在可負擔的範圍內。'):'')+'</span></div>';
 h+='<div><b>方案二：'+(ry?'延長到 '+ry.toFixed(1)+' 年（多 '+(ry-yrs).toFixed(1)+' 年）':'即使延長 80 年仍無法達標')+'</b><span>'+(ry?'時間是複利最大的助力，每月投入維持不變也能達標。':'請先提高每月投入。')+'</span></div>';
 h+='<div class="'+(rr&&rr>8?"w2":"")+'"><b>方案三：'+(rr?'報酬率需達 '+rr.toFixed(1)+'%':'需要超過 50% 的年報酬')+'</b><span>'+(rr&&rr<=o.rate+1?'與預期差距不大，值得微調資產配置。':rr&&rr<=8?'需要提高股票等成長型資產比重，風險也會提高。':'這個報酬率偏高、風險很大，不建議靠它補缺口。')+'</span></div>';
 h+='<div><b>方案四：一次投入 '+fm(gap/Math.pow(1+o.rate/100,yrs))+'</b><span>如有年終獎金、閒置存款，可一次補足缺口（PV 的意義）。</span></div>';
 h+='<div><b>方案五：降低目標至 '+fm(E/Math.pow(1+o.inf/100,yrs))+'（今天購買力）</b><span>若以上都吃力，可以調整目標金額，讓計畫更貼近現實。</span></div>'}
if(cur==3)h+='<div><b>緊急預備金的提醒</b><span>建議放在活存或定存，不要承擔波動；目標約 3 到 6 個月的生活支出。</span></div>';
if(o.rate>8)h+='<div class="w2"><b>預期報酬率 '+o.rate+'% 偏樂觀</b><span>長期穩定達到這個水準並不容易，建議用較保守的數字再試算一次。</span></div>';
$("sg").innerHTML=h;
var rows="";[-2,0,2].forEach(function(d){var r=o.rate+d,v=fv(o.pv,o.pmt,r,yrs);rows+='<tr><td>'+r.toFixed(1)+'%'+(d==0?'（預期）':'')+'</td><td>'+fm(v)+'</td><td>'+fm(v-T)+'</td><td>'+fm(reqPmt(T,o.pv,r,yrs))+'</td></tr>'});
$("sens").innerHTML='<table><tr><th>年報酬率</th><th>期末資產 FV</th><th>與目標差距</th><th>達標每月 PMT</th></tr>'+rows+'</table>'}
F.forEach(function(f){$(f).addEventListener("input",calc)});
tabs();load();calc();
